import math
import random

import pygame
import itertools

def getDistance(spot1, spot2):
    #Given two coordinates in a plane return the distance between those two points.
    dist = math.sqrt((spot1[0] - spot2[0]) ** 2 + (spot2[1] - spot2[1]) ** 2)
    return dist

def getPathDistance(places : list):
    #Given a list of x,y coordinates return the distance it would take to go to each coordinate
    # in order and then back to the start.
    dist = 0
    indices = range(0, len(places) - 1) # last index is covered in second to last iteration
    for i in indices:
        current_cords = places[i]
        next_cords = places[i+1]
        dist += getDistance(current_cords, next_cords) # find the distance to the next point, and add it
    dist *= 2 # to go back to the start, in order, you can simply
    return dist

def increment(list: list, ceiling):
    # ceiling is exclusive
    reverse_indices = range(len(list) - 1, 0, -1 ) # all indices, in reverse order
    # len is decremented since the first item in range is inclusive, and len(list) is 1 over the largest index
    # 0 stays the same, as the first index in the list (last in this range) is handled specially
    # the -1 at the end signifies that it decreases to get from the higher to the lower
    last_index = len(list) - 1
    list[last_index] += 1
    for i in reverse_indices:
        if list[i] < ceiling:
            break # no more 1s to carry
        else:
            list[i] = 0
            list[i - 1] += 1
    if list[0] > ceiling:
        return False # increments more than TSP can handle
        # this means the algorithm is over
    return  True # increments successfully

def full_TSP(places : list):
    #Check the distance of all possible different paths one could take over a set of x,y coordiantes
    #and return the path with the shortest distance
    #Print out the number of distance calculations you had to do.
    bestRoute = []
    calculations = 0
    next_place = [] # for the nth# step, what place should be chosen next?
    indices_except_last = range(0, len(places) - 1) # last index is handled by second to last index
    last_index = len(places) - 1
    for _ in places:
        next_place.append(0) # each place signifies another length on the path
    # used to find all possible combinations
    while increment(next_place, len(places) - 1): # until the last path is complete, iterate
        this_path_distance = 0
        this_route = [places[next_place[0]]]
        for i in indices_except_last:
            current_node = places[next_place[i]]
            next_node = places[next_place[i + 1]]
            this_route.append(next_node)
            calculations += 1
            this_path_distance += getDistance(current_node, next_node)
        if this_path_distance > (getPathDistance(bestRoute) / 2): # getPath is for there and back
            # but we only care about one way, not both.
            bestRoute = this_route
    print(f"there were {calculations} calculations for full TSP")
    return bestRoute

def heuristic_TSP(places : list):
    # Perform a heuristic calculation for traveling salesman.
    # For each node find the closest node to it and assume it is next node then repeat until you have your path.
    # Return the path. and print out the number of distance calculations you did.


    calculations = 0

    print(f"there were {calculations} calculations for heuristic TSP")
    return []

def generatePermutations(places : list):
    # a function that given a list will return all possible permutations of the list.
    return list(itertools.permutations(places))


def generate_RandomCoordinates(n):
    #Creates a list of random coordinates
    newPlaces = []
    for i in range(n):
        newPlaces.append([random.randint(10,790),random.randint(10,590)])
    return newPlaces

places = [[80,75],[100,520],[530,300],[280,200],[350,150],[700,120],[400,500]]


def DrawExample(places):
    #Draws the TSP showcase to the screen.
    TSP = full_TSP(places.copy())
    heuristic = heuristic_TSP(places.copy())
    # Initialize Pygame
    pygame.init()
    print(TSP)
    print(heuristic)
    # Set up the game window
    screen = pygame.display.set_mode((800, 800))
    # Game loop
    running = True
    pygame.font.init()
    font = pygame.font.SysFont(None, 48)
    text_surface = font.render('Hello, Pygame!', True, (0, 0, 0))
    text_surface.set_colorkey((0,0,0))
    text_rect = text_surface.get_rect()
    text_rect.center = (300, 700)  # Center the text on the screen
    # Arguments: text string, antialias boolean (True for smooth edges), text color, optional background color
    text_surface = font.render('Hello, Pygame!', True, (255, 255, 255))  # White text
    while running:
        screen.fill((255,255,255))
        for i in range(len(TSP)-1):
            pygame.draw.line(screen,(255,0,0),(TSP[i][0],TSP[i][1]),(TSP[i+1][0],TSP[i+1][1]),width = 8)
        if len(TSP) >=1:pygame.draw.line(screen, (255, 0, 0), (TSP[0][0], TSP[0][1]), (TSP[-1][0], TSP[-1][1]),width =8)
        for i in range(len(heuristic) - 1):
            pygame.draw.line(screen, (0, 0, 255), (heuristic[i][0], heuristic[i][1]), (heuristic[i + 1][0], heuristic[i + 1][1]), width=4)
        if len(heuristic) >=1:pygame.draw.line(screen, (0, 0, 255), (heuristic[0][0], heuristic[0][1]), (heuristic[-1][0], heuristic[-1][1]), width=4)
        for spot in places:
            pygame.draw.circle(screen, (0,0,0),(spot[0],spot[1]), 10)
        text_surface = font.render('Red is full TSP Blue is Heuristic', True, (0, 0, 0))
        screen.blit(text_surface, text_rect)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        pygame.display.flip()
    # Quit Pygame

DrawExample(places)
#DrawExample(generate_RandomCoordinates(5))# DO NOT run more than 9 or 10
pygame.quit()