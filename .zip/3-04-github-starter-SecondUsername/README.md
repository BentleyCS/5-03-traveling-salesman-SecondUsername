[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/uEyhgvly)
# Github_Setup
Simple proof that you understand how to access and setup github classroom
In the top right of this section you should see a green button that says <>Code. Click it and download the project as a zip file. 

Once you open that zip file it will contain this read me and the python script for the assignment. Open the assignment and make the required changes. 

Once done go back to the webpage and click the add file drop down and click the upload file option. Drag your python file into the new window and hit submit. 
