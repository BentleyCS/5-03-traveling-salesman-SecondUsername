
#Modify the below function such that it says your name instead.
#Then reupload it to Github classroom.
def sayHi():
    print("Hello my name is Ripley")
